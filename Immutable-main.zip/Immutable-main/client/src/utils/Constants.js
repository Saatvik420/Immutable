import abi from "./Immutable.json";

export const contractAddress = "0x804e7bd5CdeBefaa1482c1FCd625189782cAD30C";
export const contractABI = abi.abi;